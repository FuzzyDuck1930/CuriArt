export {default as ArtistCard} from "./card/card.js";
export {default as Comments } from "./comments/comments.js"
export {default as Navegation} from "./Navbar/Navbar.js"